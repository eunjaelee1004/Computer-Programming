import java.util.Scanner;

public class TicTacToe_N {
    public static void main(String[] args) {
        // Your code goes here

    }

    public static void printBoard(int[][] board) {
        System.out.println("Board:");
        for (int r = 0; r < board.length; r++) {
            for (int c = 0; c < board[0].length; c++) {
                System.out.print(board[r][c] + " ");
            }
            System.out.println();
        }
    }
}
