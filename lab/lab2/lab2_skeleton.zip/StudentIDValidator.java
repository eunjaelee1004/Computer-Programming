import java.util.Scanner; // For string input

public class StudentIDValidator {
    public static void main(String[] args) {
        // Your code goes here

    }
}
